# Field definitions

- `company`: Employer.
- `role`: Exact posting title.
- `job_id`: Official requisition or job code.
- `track`: Primary job category.
- `open_date`: Month Day, Year, Rolling, or Not listed.
- `close_date`: Month Day, Year, Rolling, or Not listed.
- `hourly_rate`: Posted rate or clearly labeled hourly estimate.
- `estimated_total_compensation`: Estimated base compensation for the stated internship duration.
- `application_url`: Official employer application page.
- `visa_sponsorship`: Sponsorship status as stated by the employer.
- `us_citizenship_required`: Explicit citizenship requirement only.
- `clearance_requirement`: Explicit clearance or export-control requirement.
