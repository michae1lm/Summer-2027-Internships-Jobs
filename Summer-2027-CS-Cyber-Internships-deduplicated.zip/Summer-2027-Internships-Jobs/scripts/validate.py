import csv
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "data" / "opportunities.csv"
with path.open(encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

seen = set()
errors = []
for line_no, row in enumerate(rows, start=2):
    key = (row["company"].strip().lower(), (row["job_id"] or row["role"]).strip().lower())
    if key in seen:
        errors.append(f"Row {line_no}: duplicate {key}")
    seen.add(key)
    if not row["application_url"].startswith("http"):
        errors.append(f"Row {line_no}: missing official URL")

if errors:
    raise SystemExit("\n".join(errors))
print(f"Validated {len(rows)} unique opportunities.")
